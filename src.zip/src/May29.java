
import java.util.*;

public class May29 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		
		Scanner sc = new Scanner(System.in);
		System.out.println("please select the option");
		System.out.println("1. idly");
		System.out.println("2. dosa");
		
	int input,count;
		input= sc.nextInt();
		
//		nextLine()
//		nextFloat()
//		next()
		
		
		switch(input) {
		
		case 1:
			System.out.println("how many count");
			count= sc.nextInt();
			System.out.println("price" + " " + count*5);
			break;
		case 2:
			
			System.out.println("case 10");
			break;
		default:
			System.out.println("default");
		
		
		}
		
		

	}

}
